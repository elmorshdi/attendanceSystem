package com.attendance.system;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;

public class recordattendActivity extends AppCompatActivity {
    int year= 2020,month=7,day=9;
    EditText editdat,editid ,editccode;
    ListView listView;
    TextView textView;
    String date,cousecode,id,tag;
    ArrayList<String>arrayList=new ArrayList<String>();
    ArrayList<String>arrayscan=new ArrayList<String>();
    ArrayAdapter<String> itemsAdapter;
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recordattend);


        listView =findViewById(R.id.list);
        textView=findViewById(R.id.numtxt);
        editdat = findViewById(R.id.datepicker);
        editid =findViewById(R.id.stu_id);
        editccode =findViewById(R.id.cours_code);
        final SwipeRefreshLayout pullToRefresh = findViewById(R.id.pullToRefresh);
        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                listView.setAdapter(itemsAdapter);
                pullToRefresh.setRefreshing(false);
            }
        });
        pref = getSharedPreferences("id", MODE_PRIVATE);
        if (pref.contains("cours_code")) {
           editccode.setText(get_object("cours_code"));
        }
        if (pref.contains("date")) {
            editdat.setText(get_object("date"));
        }
        arrayList=getArrayList("all_id");
        if (arrayList==null)arrayList=new ArrayList<String>();
        itemsAdapter=new ArrayAdapter<String>(this,R.layout.item,R.id.texti, arrayList);
        listView.setAdapter(itemsAdapter);
        editdat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdatediloge();
            }


        });

    }

    @Override
    protected void onPause() {
        if(editccode.getText().length()>4)saveobject(editccode.getText().toString(),"cours_code");
        if(editdat.getText().length()>4)saveobject(editccode.getText().toString(),"date");
        super.onPause();
    }

    @Override
    protected void onResume() {
       /* arrayscan = getArrayList("arraylistscand");
       for (String s :arrayscan ) { itemsAdapter.add(s); }
      //  arrayList.addAll(arrayscan);
        saveArrayList(arrayList,"all_id");
        Log.d(tag, "size"+arrayList.size());
        arrayscan.clear();
        arrayList=getArrayList("all_id");
        if (arrayList==null)arrayList=new ArrayList<String>();
        listView.setAdapter(itemsAdapter);*/
        super.onResume();
    }





    private void showdatediloge() {

        DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                editdat.setText(dayOfMonth+"-"+month+ "-"+year);

            }
        };


        DatePickerDialog datePickerDialog= new DatePickerDialog(recordattendActivity.this,  listener, year, month, day);

        datePickerDialog.show();

    }

    public void go_home(View view) {
        Intent intent= new Intent(recordattendActivity.this,HomeActivity.class);
        startActivity(intent);
    }

    public void goto_qr(View view) {
        Intent intent= new Intent(recordattendActivity.this,scanActivity.class);
        startActivity(intent);
    }

    public void addid(View view)
    {
        id=editid.getText().toString();
        if (!(id.length()<9))
        {
            id=editid.getText().toString();
            editid.setText("");
            arrayList=getArrayList("all_id");
            if (arrayList==null)arrayList=new ArrayList<String>();
            arrayList.add(id);
            listView.setAdapter(itemsAdapter);
            saveArrayList(arrayList,"all_id");

        }else editid.setError("add id");
        Toast.makeText(this, "added", Toast.LENGTH_SHORT).show();

    }

    public void uploud(View view) {
        arrayList=getArrayList("all_id");
        SharedPreferences.Editor editor = pref.edit();
        editor.clear();
        editor.apply();

        Toast.makeText(this, "tes", Toast.LENGTH_SHORT).show();

    }
    private void  saveobject(String s,String key){
        SharedPreferences prefs = getSharedPreferences("id", MODE_PRIVATE);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key, s);
        editor.apply();
    }
    private String get_object(String key){
        SharedPreferences prefs = getSharedPreferences("id", MODE_PRIVATE);
        String s=prefs.getString(key, null);
        return s;
    }
    private void saveArrayList(ArrayList<String> list, String key){
        SharedPreferences prefs = getSharedPreferences("id", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();
        String list_in_json = gson.toJson(list);
        editor.putString(key, list_in_json);
        editor.apply();
    }
    public ArrayList<String> getArrayList(String key){
        SharedPreferences prefs = getSharedPreferences("id", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString(key, null);
        Type type = new TypeToken<ArrayList<String>>() {}.getType();
        return gson.fromJson(json, type);
    }

}
